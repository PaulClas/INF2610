/*
 * Init Lab - q2.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _Q2_H
#define _Q2_H

void question2();

#endif