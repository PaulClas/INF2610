/*
 * Init Lab - libq2.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _LIBQ2_H
#define _LIBQ2_H

void evaluateQuestion2();

#endif