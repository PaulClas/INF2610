/*
 * Init Lab - answers-q5.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _ANSWERS_Q5_H
#define _ANSWERS_Q5_H

// -----------------------------------------------------------------
// Reportez ici les réponses que vous avez trouvées à la question 5.
// -----------------------------------------------------------------

// Report here the answer for question 5. a)
char Q5_ANS_A[] = ""; //TODO

// Report here the answer for question 5. b)
char Q5_ANS_B[] = ""; //TODO

// Report here the answer for question 5. c)
char Q5_ANS_C[] = ""; //TODO

// Report here the answer for question 5. d)
char Q5_ANS_D[] = ""; //TODO

// Report here the answer for question 5. e)
char Q5_ANS_E[] = ""; //TODO

#endif