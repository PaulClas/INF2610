/*
 * Init Lab - libq3.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _LIBQ3_H
#define _LIBQ3_H

void evaluateQuestion3();

#endif