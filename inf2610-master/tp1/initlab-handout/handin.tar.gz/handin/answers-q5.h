/*
 * Init Lab - answers-q5.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _ANSWERS_Q5_H
#define _ANSWERS_Q5_H

// -----------------------------------------------------------------
// Reportez ici les réponses que vous avez trouvées à la question 5.
// -----------------------------------------------------------------

// Report here the answer for question 5. a)
char Q5_ANS_A[] = "/tmp/filewriter_secret_cfec7d0995f12112"; 

// Report here the answer for question 5. b)
char Q5_ANS_B[] = "/tmp/filewriter_secret_child_54e3d59ca2628134"; 

// Report here the answer for question 5. c)
char Q5_ANS_C[] = "0523cbe6205a699e5755cada1b0f0880cf026c3eb0874cc8107ed47d3861d186";

// Report here the answer for question 5. d)
char Q5_ANS_D[] = "fputs"; 

// Report here the answer for question 5. e)
char Q5_ANS_E[] = "PAUSE"; 

#endif