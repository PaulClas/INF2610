// TODO Includes
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>


#define FILE_NAME "question1.txt"

void ecritureFichier() {
    // TODO
    //String debutString, milieuString, finString;
    
    int file = open("question1.txt" , O_WRONLY);
    
    pid_t process = getpid();
    char process_PID[100] ;
    pid_t parent = getppid();
    char parent_PID[100] ;
    
    //File* filename=fopen(question.txt, "w+");
    //sprintf(PARENT_PROCESS_PID,"%d",getppid());
    /*
    debutString = "Fichier ouvert par le processus/n)";
    strcopy(milieuString, " du processus ouvrant le fichier et/n");
    strcopy(finString, "et le PID du processus parent du processus ayant ouvert le fichier./n");

    write(file, debutString, strlen(debutString));
    write(file, getPid(), strlen(getPid()));
    write(file, milieuString, strlen(milieuString));
    write(file, PARENT_PROCESS_PID, strlen(PARENT_PROCESS_PID));
    write(file, finString, strlen(finString));
    */
    sprintf(process_PID,"%d", process);
    sprintf(parent_PID,"%d", parent);
    
    //write(file, PARENT_PROCESS_PID, strlen(PARENT_PROCESS_PID));
    write(file, "Fichier ouvert par le processus ", strlen("Fichier ouvert par le processus "));
    write(file, process_PID, strlen(process_PID));
    write(file, " de parent ", strlen(" de parent "));
    write(file, parent_PID, strlen(parent_PID));
    write(file, ".\n", strlen(".\n"));
    
    //close(file);
    
    
    
    //write(file, debutString, getPid(), " du processus ouvrant le fichier et ", PARENT_PROCESS_PID,"et le PID du processus parent du processus ayant ouvert le fichier./n");
    //fprintf(file,"Fichier ouvert par le processus ", getPid(), " du processus ouvrant le fichier et ", PARENT_PROCESS_PID,"et le PID du processus parent du processus ayant ouvert le fichier./n");
    
    close(file);
    
    
    
    
}
