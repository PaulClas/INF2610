// TODO Includes
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdin.h>


#define FILE_NAME "question1.txt"

void ecritureFichier() {
    // TODO
    String debutString, milieuString, finString;
    char PARENT_PROCESS_PID[100];
    int file = open("question.txt", )_WRONLY);
    //File* filename=fopen(question.txt, "w+");
    sprintf(PARENT_PROCESS_PID,"%d",getPid());
    
    strcopy(debutString, "Fichier ouvert par le processus/n");
    strcopy(milieuString, " du processus ouvrant le fichier et/n");
    strcopy(finString, "et le PID du processus parent du processus ayant ouvert le fichier./n");
    
    write(file, debutString, strlen(debutString));
    write(file, getPid(), strlen(getPid());
    write(file, milieuString, strlen(milieuString));
    write(file, PARENT_PROCESS_PID, strlen(PARENT_PROCESS_PID));
    write(file, finString, strlen(finString));
    close(file);
    
    
    
    //write(file, debutString, getPid(), " du processus ouvrant le fichier et ", PARENT_PROCESS_PID,"et le PID du processus parent du processus ayant ouvert le fichier./n");
    //fprintf(filename,"Fichier ouvert par le processus ", getPid(), " du processus ouvrant le fichier et ", PARENT_PROCESS_PID,"et le PID du processus parent du processus ayant ouvert le fichier./n");
    
    
    
    
}
