// NE PAS TOUCHER
#include "../Evaluateur/evaluateur.h"

// TODO Includes
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdint.h>


void construireArbre() {
    // TODO
    //,P2,P3,P4,P5,P6,P7;
    pid_t pidFils = fork();
    //int pid[100];
    
    /*if(pidFils ==0){
        if(fork()==0)
    }
    */
    if(pidFils ==0){
        // fork P1
        if(!fork()){
            pid_t P1 = getpid();
            helloFromProcess(P1);
            //fork P4
            if(fork()==0){
                pid_t P4 = getpid();
                helloFromProcess(P4);
                wait(NULL);
            }
            // fork P5
            if(fork()==0){
                pid_t P5 = getpid();
                helloFromProcess(P5);
            }
            wait(NULL);
        }
        wait(NULL);
        if(!fork()){
            pid_t P2 = getpid();
            helloFromProcess(P2);
            if(fork()==0){
                pid_t P6 = getpid();
                helloFromProcess(P6);
                if(fork()==0){
                    pid_t P7 = getpid();
                    helloFromProcess(P7);
                }
                wait(NULL);
            }
            wait(NULL);
        }
        wait(NULL);
        if(!fork()){
            pid_t P3 = getpid();
            helloFromProcess(P3);
        }
        wait(NULL);
    }
    pid_t P0 = getpid();
    helloFromProcess(P0);
    wait(NULL);
    
}




void transformerCode() {
        // TODO
}
