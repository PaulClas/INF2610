#!/bin/bash

cd Evaluateur/
PYTHONIOENCODING=UTF-8 python3 grader.py
cd ..