import os
import subprocess
import codecs

class Process:
    def __init__(self, pid):
        self.pid = pid
        self.children = []

def findProcess(array, pid):
    found = False
    for item in array:
        if item.pid == pid:
            found = True
            break
    return found

def getProcess(array, pid):
    for item in array:
        if item.pid == pid:
            return item
    return None

def getCloneLogs():
    clonelogs = []
    with codecs.open("straceout.log", 'r', encoding='utf-8', errors='ignore') as stracelogs:
        for line in stracelogs:
            if line.find("clone") >= 0 and line.find("clone( <unfinished ...>") == -1 and line.find("<unfinished ...>") == -1:
                clonelogs.append(line)
    return clonelogs

def evaluateQuestion1():
    # Checking function restrictions
    os.system("ltrace -s 200 -f -o ltraceout.log ./main.out")
    os.system("cp question1.txt ../Section1")
    ltracelogs = codecs.open("./ltraceout.log", 'r', encoding='utf-8', errors='ignore')
    correctFunctions = True
    for line in ltracelogs:
        if (line.find("fopen") != -1 or line.find("fprintf") != -1 or line.find("fclose") != -1 ):
            correctFunctions = False
    
    # Checking output
    gradingfile = codecs.open("./grading.log", 'r', encoding='utf-8', errors='ignore')
    correctOutput = True
    for line in gradingfile:
        if (line.find("BAD_STRING") >= 0):
            correctOutput = False
            break
    
    # Grading
    if (not correctFunctions and not correctOutput):
        print("QUESTION 1 : Pointage (0/8)")
        print("\tAvez-vous uniquement utilisé les fonctions open, write et close?")

    if (not correctOutput):
        print("QUESTION 1 : Pointage (0/8)")
        phraseVoulue = ""
        phraseObtenue = ""
        for line in gradingfile:
            if (line.find("PHRASE_VOULUE") >= 0):
                phraseVoulue = line.split("PHRASE_VOULUE:")[1]
            if (line.find("PHRASE_OBTENUE") >= 0):
                phraseObtenue = line.split("PHRASE_OBTENUE:")[1]
        print("\tPHRASE OBTENUE: " + phraseObtenue)
        print("\tPHRASE VOULUE: " + phraseVoulue)
        print("\t\tVous avez peut-être oublié le caractère de fin de ligne ou le point à la fin de la phrase.")
        print("\t\tVous avez peut-être mal retranscrit la phrase (faute d'ortographe, pids, etc.).")
        return
    
    if (not correctFunctions and correctOutput):
        print("QUESTION 1 : Pointage (4/8)")
        print("\tAvez-vous uniquement utilisé les fonctions open, write et close?")
        return
    
    print("QUESTION 1 : Bien joué!")
    os.system("rm grading.log")

def evaluateQuestion2():
    os.system("strace -s 200 -f -o straceout.log ./main.out")
    gradingfile = codecs.open("./grading.log", 'r', encoding='utf-8', errors='ignore')
    
    # Get the root PID
    rootProcess = None
    for line in gradingfile:
        if (line.find("ROOT_PID") >= 0):
            rootProcess = Process(int(line.split("ROOT_PID:")[1]))
    
    if (rootProcess is None):
        print("FATAL ERROR: CANNOT FIND ROOT PROCESS PID")
        return
    
    # ANALYSE FILES AND CREATE PROCESSES RECORDS
    processes = [rootProcess]
    gradingfile = codecs.open("./grading.log", 'r', encoding='utf-8', errors='ignore')
    for line in gradingfile:
        if (line.find("Section2:") == -1 or line.find("ROOT_PID") >= 0):
            continue
        # We have a good line containing pids
        fatherPidToAdd = int(line.split(">")[1].split("-")[1])
        if findProcess(processes, fatherPidToAdd):
            # Check if already have children of the left
            # If not, add to array of children and add child to processes list
            father = getProcess(processes, fatherPidToAdd)
            childPid = int(line.split(">")[1].split("-")[0])
            if not findProcess(father.children, childPid):
                newProcess = Process(childPid)
                father.children.append(newProcess)
                processes.append(newProcess)
            
        else:
            # add to processes and add the left pid to its children
            processes.append(Process(fatherPidToAdd))
    
    pointage = 0
    # Check that rootProcess has 3 children
    print("QUESTION 2 : Messages")
    firstConstraint = rootProcess.children.__len__() == 3
    if not firstConstraint:
        print("\tATTENTION : le sous-arbre de P0 n'est pas correct")
    else:
        pointage += 2
    # Check that one child has 2 children with no child
    secondConstraint = False
    for child in rootProcess.children:
        if (child.children.__len__() == 2):
            secondConstraint = child.children[0].children.__len__() == 0 and child.children[1].children.__len__() == 0 
    if (not secondConstraint):
        print("\tATTENTION : Le sous-arbre de P1 est peut-etre incorrect")
    else:
        pointage += 2

    thirdConstraint = False
    for child in rootProcess.children:
        # Check that one child has one child
        if child.children.__len__() == 1:
            if child.children[0].children.__len__() == 1:
                if child.children[0].children[0].children.__len__() == 0:
                    thirdConstraint = True
                    break
    if not thirdConstraint:
        print("\tATTENTION : Le sous-arbre de P2 est peut-etre incorrect")
    else:
        pointage += 2
    # Check that one child has no child
    fourthConstraint = False
    for child in rootProcess.children:
        if (child.children.__len__() == 0):
            fourthConstraint = True
            break
    if not fourthConstraint:
        print("\tATTENTION : Le sous-arbre de P3 est peut-etre incorrect")
    else:
        pointage += 2
    
    if pointage < 8:
        print(f"QUESTION 2 : Pointage ({pointage}/8)")
        print("\tATTENTION : Arbre incorrect: êtes-vous certain que chaque processus attend ses fils avant de se terminer?")
    
    clonelogs = getCloneLogs()
    validTree = True
    straceChecked = True
    
    # for each process check if logs are valid
    for process in processes:
        processCloneCalls = []
        # Getting clone calls made by this process
        for clonelog in clonelogs:
            if (clonelog.find(str(process.pid)) == 0):
                processCloneCalls.append(clonelog)
        # Checking that clone returns values are the children of the process
        for processCloneCall in processCloneCalls:
            formattedCloneCall = processCloneCall.split("=")
            createdProcessAfterCall = int(formattedCloneCall[formattedCloneCall.__len__() - 1].split(" ")[1])
            # check that it is contained in children
            validChild = False
            for child in process.children:
                if child.pid == createdProcessAfterCall:
                    validChild = True
            if (not validChild):
                straceChecked = False
                break
        if (not straceChecked):
            validTree = False
            break
    if (validTree and pointage == 8):
        print("QUESTION 2 : Bien joué!")
    else:
        print("\tQUESTION 2 : La structure de l'arbre ne respecte pas l'énoncé.")

    os.system("rm grading.log")

def evaluateQuestion3():
    os.system("./main.out")
    goodUsage = False
    gradingfile = codecs.open("./grading.log", 'r', encoding='utf-8', errors='ignore')
    for line in gradingfile:
        if line.find("Section3:") == 0:
            goodUsage = line.split(":")[1].strip() == "OK"
            break
    if (goodUsage):
        print("QUESTION 3 : Bien joué!")
    else:
        print("QUESTION 3 : Pointage (0/4)")
        print("\tVérifiez l'usage du programme welcomeProcess")

def cleanallfiles():
    os.system("rm -f main.out grading.log straceout.log ltraceout.log question1.txt welcomeProcess")

def cleanq1files():
    os.system("rm -f main.out grading.log ltraceout.log question1.txt welcomeProcess")

# MAIN ENTRY POINT
try:
    
    os.system("touch question1.txt")
    os.system("cp ../Section2/welcomeProcess ./welcomeProcess")
    os.system("gcc -D_FORTIFY_SOURCE=1 -fstack-protector-strong -Wall -O -g -c ../main.c")
    os.system("gcc -o main.out main.o evaluateur.o")
    os.system("rm main.o")

    evaluateQuestion1()
    print("\n")
    evaluateQuestion2()
    print("\n")
    evaluateQuestion3()
    print("\n")
except OSError as e:
    cleanallfiles()
    exit()
    
cleanallfiles()
