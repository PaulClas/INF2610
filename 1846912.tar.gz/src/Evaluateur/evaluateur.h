#ifndef __EVALUATEUR_H__
#define __EVALUATEUR_H__

#define BUFF_SIZE 256

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>

int compareStrings(char* s1, char* s2, int maxLen);
void report(char* reportStr);
void helloFromProcess(pid_t pid);
void evaluerQuestionFichier(void (*fonctionEtudiant)(void));
void evaluerQuestion2(void (*fonctionEtudiant)(void));
void evaluerQuestion3(uint8_t goodPID, uint8_t gootTag);

#endif