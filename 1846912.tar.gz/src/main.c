// NE PAS TOUCHER
#include "Section1/QuestionFichier.c"
#include "Section2/QuestionArbre.c"

// NE PAS TOUCHER
int main() {
    evaluerQuestionFichier(ecritureFichier);
    evaluerQuestion2(construireArbre);
    transformerCode();
}
